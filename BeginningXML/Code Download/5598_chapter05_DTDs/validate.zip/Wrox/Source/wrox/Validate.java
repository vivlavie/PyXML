package wrox;

/**
 * Title:        Wrox Xerces Validator
 * Description:  Class used for validating an instance
  *              document with a XML Schema or DTD
 * Copyright:    Copyright (c) 2001
 * Company:      Wrox Press
 * @author       Jeff Rafter
 * @version      1.0
 */
 
import org.w3c.dom.Document;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;


public class Validate
  implements ErrorHandler {

  private String instance = null;
  private String schema = null;
  private String output = null;
  private int warnings = 0;
  private int errors = 0;
  private int fatalErrors = 0;

  private org.apache.xerces.parsers.DOMParser parser = 
    new org.apache.xerces.parsers.DOMParser();

  public void setInstance(String s) {
    instance = s;  
  }
  
  public void setSchema(String s) {
    schema = s;
  }

  public void setOutput(String s) {
    output = s;
  }

  public boolean doValidate() {
    try { 
      warnings = 0;
      errors = 0;
      fatalErrors = 0;
      try {          
        // Turn the validation feature on
        parser.setFeature( "http://xml.org/sax/features/validation", true);   
        // If there is an external schema set it
        if (schema != null) {
          parser.setProperty("http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation", schema);
        }
        // Parse and validate
        System.out.println("Validating source document...");
        parser.parse(instance);
        // We parsed... let's give some summary info of what we did
        System.out.println("");
        System.out.println("Complete " + warnings + " warnings " + errors + " errors " + fatalErrors + " fatal errors");
        
        // Return true if we made it this far with no errors
        return ((errors == 0) && (fatalErrors == 0));
        
      } catch (SAXException e) {
        System.out.println("");
        System.err.println("Could not activate validation features - " + e.getMessage());
        return false;
      }
                  
    } catch (Exception e) {
      System.out.println("");
      System.err.println(e.getMessage());
      return false;
    }   
  } 
  
  public void warning(SAXParseException ex) {
     System.out.println("");
     System.err.println("[Warning] " + ex.getMessage() + 
       " line " + ex.getLineNumber() + " column " + ex.getColumnNumber() + 
       " - " + instance);
     warnings++;  
  }

  public void error(SAXParseException ex) {
     System.out.println("");
     System.err.println("[Error] " + ex.getMessage() + 
       " line " + ex.getLineNumber() + " column " + ex.getColumnNumber() + 
       " - " + instance);
     errors++;  
  }

  public void fatalError(SAXParseException ex) throws SAXException {
     System.out.println("");
     System.err.println("[Fatal Error] " + ex.getMessage() + 
       " line " + ex.getLineNumber() + " column " + ex.getColumnNumber() + 
       " - " + instance);
     
     fatalErrors++;  
     
     throw ex;  
  }

  public Validate() {
    // Set the errorHandler  
    parser.setErrorHandler(this);    
  }
  
  public static void main(String[] args) {
    Validate validate1 = new Validate();
    if (args.length == 0) {
      System.out.println("Usage : java wrox.Validate <instance> [-o output]");
      return;     
    }
    // Set the instance
    if (args.length >= 1) {
      validate1.setInstance(args[0]);   
    }
    // Set the Schema or output
    if (args.length >= 2) {    
      if ("-o".equalsIgnoreCase(args[1])) {
        if (args.length >= 3) {
          validate1.setOutput(args[2]);
        }
      } else {
        validate1.setSchema(args[1]);
      }
    }

    // Set the output
    if (args.length >= 3) {
      if ("-o".equalsIgnoreCase(args[2])) {
        if (args.length >= 4) {
          validate1.setOutput(args[3]);
        }
      }
    }

    // Validate
    if (!validate1.doValidate()) return;
  }

  
}
